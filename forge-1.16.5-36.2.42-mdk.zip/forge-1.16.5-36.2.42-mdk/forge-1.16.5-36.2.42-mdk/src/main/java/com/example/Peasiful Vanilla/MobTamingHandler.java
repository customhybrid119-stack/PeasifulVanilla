package net.example.peasifulvanilla;

import net.minecraft.entity.CreatureEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ai.goal.NearestAttackableTargetGoal;
import net.minecraft.entity.monster.CreeperEntity;
import net.minecraft.entity.monster.SkeletonEntity;
import net.minecraft.entity.monster.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.UUID;

public class MobTamingHandler {

    // Логика клика правой кнопкой мыши по мобу
    @SubscribeEvent
    public void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        PlayerEntity player = event.getPlayer();
        Entity target = event.getTarget();
        ItemStack heldItem = player.getItemInHand(event.getHand());

        // Проверяем, что действие происходит на сервере игры и в главной руке
        if (event.getWorld().isClientSide() || event.getHand() != Hand.MAIN_HAND) return;

        // Если моб уже кем-то приручен, ничего не делаем
        CompoundNBT nbt = target.getPersistentData();
        if (nbt.getBoolean(PeasifulVanilla.TAMED_TAG)) return;

        boolean canTame = false;

        // ТВОЙ КОНЦЕПТ: Проверяем тип моба и предмет в руке
        if (target instanceof ZombieEntity && heldItem.getItem().isEdible() && heldItem.getItem().getFoodProperties().isMeat()) {
            canTame = true; // Зомби + любое мясо
        } else if (target instanceof SkeletonEntity && heldItem.getItem() == Items.APPLE) {
            canTame = true; // Скелет + яблоко
        } else if (target instanceof CreeperEntity && heldItem.getItem() == Items.BONE_MEAL) {
            canTame = true; // Крипер + костная мука
        }

        if (canTame) {
            // Если игрок в выживании — забираем 1 предмет
            if (!player.isCreative()) {
                heldItem.shrink(1);
            }

            // Записываем в скрытую память моба, что он теперь ручной
            nbt.putBoolean(PeasifulVanilla.TAMED_TAG, true);
            nbt.putUUID(PeasifulVanilla.OWNER_TAG, player.getUUID());

            // Меняем мозги (AI) моба прямо сейчас
            if (target instanceof CreatureEntity) {
                applyTamedAI((CreatureEntity) target);
            }

            // Пишем игроку в чат
            player.sendMessage(new StringTextComponent("Вы приручили монстра!"), player.getUUID());
            
            event.setCanceled(true);
            event.setCancellationResult(ActionResultType.SUCCESS);
        }
    }

    // Логика для того, чтобы моб оставался прирученным после перезахода в мир
    @SubscribeEvent
    public void onEntityJoinWorld(EntityJoinWorldEvent event) {
        if (event.getWorld().isClientSide() || !(event.getEntity() instanceof CreatureEntity)) return;

        CreatureEntity entity = (CreatureEntity) event.getEntity();
        CompoundNBT nbt = entity.getPersistentData();

        // Если моб заспавнился/загрузился в чанке и у него есть наша метка — перестраиваем ему AI
        if (nbt.getBoolean(PeasifulVanilla.TAMED_TAG)) {
            applyTamedAI(entity);
        }
    }

    // Метод, который заставляет мобов атаковать своих
    private void applyTamedAI(CreatureEntity entity) {
        // Очищаем старые цели атаки (чтобы они больше не агрились на игроков)
        entity.targetSelector.getRunningGoals().forEach(goal -> entity.targetSelector.removeGoal(goal.getGoal()));
        entity.setTarget(null); // Сбрасываем текущую цель, если он уже за кем-то бежал

        // Добавляем новую цель: бить сородичей, которые НЕ приручены
        if (entity instanceof ZombieEntity) {
            entity.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(entity, ZombieEntity.class, true, (target) -> {
                return target != entity && !target.getPersistentData().getBoolean(PeasifulVanilla.TAMED_TAG);
            }));
        } 
        else if (entity instanceof SkeletonEntity) {
            entity.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(entity, SkeletonEntity.class, true, (target) -> {
                return target != entity && !target.getPersistentData().getBoolean(PeasifulVanilla.TAMED_TAG);
            }));
        } 
        else if (entity instanceof CreeperEntity) {
            entity.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(entity, CreeperEntity.class, true, (target) -> {
                return target != entity && !target.getPersistentData().getBoolean(PeasifulVanilla.TAMED_TAG);
            }));
        }
    }
}
