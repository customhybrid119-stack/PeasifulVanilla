package net.example.peasifulvanilla;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;

@Mod(PeasifulVanilla.MOD_ID)
public class PeasifulVanilla {
    // ID твоего мода маленькими буквами. Он должен совпадать с тем, что в файле mods.toml
    public static final String MOD_ID = "peasifulvanilla";

    // Названия меток, которые мы будем сохранять в память мобам
    public static final String TAMED_TAG = "IsTamedByPlayer";
    public static final String OWNER_TAG = "PlayerOwnerUUID";

    public PeasifulVanilla() {
        // Подключаем наш обработчик приручения к игре
        MinecraftForge.EVENT_BUS.register(new MobTamingHandler());
    }
}
