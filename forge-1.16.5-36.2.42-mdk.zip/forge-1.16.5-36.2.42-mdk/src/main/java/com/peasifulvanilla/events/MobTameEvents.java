package com.peasifulvanilla.events;

import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import net.minecraft.entity.monster.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;

import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;

import net.minecraft.util.text.StringTextComponent;

public class MobTameEvents {

    @SubscribeEvent
    public void onInteract(
            PlayerInteractEvent.EntityInteract event
    ) {

        if(event.getTarget() instanceof ZombieEntity) {

            PlayerEntity player = event.getPlayer();

            ItemStack item =
                    player.getMainHandItem();

            if(item.getItem() == Items.BEEF) {

                player.sendMessage(
                        new StringTextComponent(
                                "Zombie tamed!"
                        ),
                        player.getUUID()
                );
            }
        }
    }
}