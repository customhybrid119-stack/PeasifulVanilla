package com.peasifulvanilla.events;

import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.CreeperEntity;
import net.minecraft.entity.monster.MonsterEntity;
import net.minecraft.entity.monster.SkeletonEntity;
import net.minecraft.entity.monster.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;

import net.minecraft.item.Item;
import net.minecraft.item.Items;

import net.minecraft.nbt.CompoundNBT;

import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.text.StringTextComponent;

import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.living.LivingEvent;

import net.minecraftforge.eventbus.api.SubscribeEvent;

public class MobInteractHandler {

    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {

        PlayerEntity player = event.getPlayer();
        Entity target = event.getTarget();

        // Только зомби, скелеты и криперы
        if (!(target instanceof ZombieEntity
                || target instanceof SkeletonEntity
                || target instanceof CreeperEntity)) {
            return;
        }

        Item item = player.getItemInHand(Hand.MAIN_HAND).getItem();

        // Разрешённая еда
        boolean validFood =
                item == Items.BEEF ||
                item == Items.COOKED_BEEF ||
                item == Items.PORKCHOP ||
                item == Items.COOKED_PORKCHOP ||
                item == Items.MUTTON ||
                item == Items.COOKED_MUTTON;

        if (!validFood) {
            return;
        }

        MonsterEntity monster = (MonsterEntity) target;

        CompoundNBT data = monster.getPersistentData();

        // Уже приручен
        if (data.getBoolean("Peasiful")) {
            player.displayClientMessage(
                    new StringTextComponent("Нежить уже приручена!"),
                    true
            );

            event.setCancellationResult(ActionResultType.SUCCESS);
            event.setCanceled(true);
            return;
        }

        // Приручение
        data.putBoolean("Peasiful", true);
        data.putString("Owner", player.getName().getString());

        // Убираем 1 еду
        if (!player.isCreative()) {
            player.getItemInHand(Hand.MAIN_HAND).shrink(1);
        }

        // Сообщение
        player.displayClientMessage(
                new StringTextComponent("Нежить приручена!"),
                true
        );

        // Моб перестаёт атаковать
        monster.setTarget(null);

        event.setCancellationResult(ActionResultType.SUCCESS);
        event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onLivingUpdate(LivingEvent.LivingUpdateEvent event) {

        // Только монстры
        if (!(event.getEntityLiving() instanceof MonsterEntity)) {
            return;
        }

        MonsterEntity monster = (MonsterEntity) event.getEntityLiving();

        CompoundNBT data = monster.getPersistentData();

        // Только приручённые
        if (!data.getBoolean("Peasiful")) {
            return;
        }

        // Не атакует игрока
        monster.setTarget(null);

        String ownerName = data.getString("Owner");

        PlayerEntity nearestPlayer = monster.level.getNearestPlayer(monster, 20);

        if (nearestPlayer == null) {
            return;
        }

        // Только за хозяином
        if (!nearestPlayer.getName().getString().equals(ownerName)) {
            return;
        }

        // Идёт за игроком
        monster.getNavigation().moveTo(nearestPlayer, 1.0D);
    }
} ||