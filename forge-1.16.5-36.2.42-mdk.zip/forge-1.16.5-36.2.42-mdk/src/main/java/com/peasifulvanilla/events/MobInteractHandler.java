package com.peasifulvanilla.events;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.monster.CreeperEntity;
import net.minecraft.entity.monster.MonsterEntity;
import net.minecraft.entity.monster.SkeletonEntity;
import net.minecraft.entity.monster.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.util.Hand;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class MobInteractHandler {

    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {

        // Только MAIN_HAND
        if (event.getHand() != Hand.MAIN_HAND) {
            return;
        }

        Entity entity = event.getTarget();

        if (!(entity instanceof LivingEntity)) {
            return;
        }

        LivingEntity target = (LivingEntity) entity;
        PlayerEntity player = event.getPlayer();

        Item item = player.getItemInHand(Hand.MAIN_HAND).getItem();

        // Только зомби, скелеты, криперы
        if (!(target instanceof ZombieEntity ||
              target instanceof SkeletonEntity ||
              target instanceof CreeperEntity)) {
            return;
        }

        // Проверка еды
        if (!isTamingFood(item)) {
            return;
        }

        CompoundNBT data = target.getPersistentData();

        // Уже приручен
        if (data.getBoolean("Peasiful")) {
            return;
        }

        // Сохраняем приручение
        data.putBoolean("Peasiful", true);

        // Убираем агрессию
        if (target instanceof MonsterEntity) {
            ((MonsterEntity) target).setTarget(null);
        }

        // Тратим 1 еду
        if (!player.isCreative()) {
            player.getItemInHand(Hand.MAIN_HAND).shrink(1);
        }

        // Одно сообщение
        player.sendMessage(
                new StringTextComponent(target.getName().getString() + " is now peaceful!"),
                player.getUUID()
        );

        event.setCanceled(true);
    }

    // Каждый тик делаем моба мирным
    @SubscribeEvent
    public static void onWorldTick(TickEvent.WorldTickEvent event) {

        for (Entity entity : event.world.entitiesForRendering()) {

            if (entity instanceof MonsterEntity) {

                MonsterEntity monster = (MonsterEntity) entity;

                CompoundNBT data = monster.getPersistentData();

                if (data.getBoolean("Peasiful")) {

                    // Не атакует игрока
                    monster.setTarget(null);

                    // Не злится
                    monster.setAggressive(false);
                }
            }
        }
    }

    private static boolean isTamingFood(Item item) {

        return item == Items.BEEF ||
               item == Items.COOKED_BEEF ||

               item == Items.PORKCHOP ||
               item == Items.COOKED_PORKCHOP ||

               item == Items.MUTTON ||
               item == Items.COOKED_MUTTON;
    }
}