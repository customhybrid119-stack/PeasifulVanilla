package com.peasifulvanilla.events;

import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.CreeperEntity;
import net.minecraft.entity.monster.MonsterEntity;
import net.minecraft.entity.monster.SkeletonEntity;
import net.minecraft.entity.monster.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;

import net.minecraft.item.Item;
import net.minecraft.item.Items;

import net.minecraft.nbt.CompoundNBT;

import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.text.StringTextComponent;

import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.living.LivingEvent;

import net.minecraftforge.eventbus.api.SubscribeEvent;

public class MobInteractHandler {

    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {

        PlayerEntity player = event.getPlayer();
        Entity target = event.getTarget();

        // Только нужные мобы
        if (!(target instanceof ZombieEntity
                || target instanceof SkeletonEntity
                || target instanceof CreeperEntity)) {
            return;
        }

        Item item = player.getItemInHand(Hand.MAIN_HAND).getItem();

        // Разрешённая еда
        boolean validFood =
                item == Items.BEEF ||
                item == Items.COOKED_BEEF ||
                item == Items.PORKCHOP ||
                item == Items.COOKED_PORKCHOP ||
                item == Items.MUTTON ||
                item == Items.COOKED_MUTTON;

        if (!validFood) {
            return;
        }

        MonsterEntity monster = (MonsterEntity) target;

        CompoundNBT data = monster.getPersistentData();

        // Уже приручён
        if (data.getBoolean("Peasiful")) {

            player.displayClientMessage(
                    new StringTextComponent("Нежить уже приручена!"),
                    true
            );

            event.setCancellationResult(ActionResultType.SUCCESS);
            event.setCanceled(true);

            return;
        }

        // Приручение
        data.putBoolean("Peasiful", true);
        data.putString("Owner", player.getName().getString());

        // Убираем 1 предмет
        if (!player.isCreative()) {
            player.getItemInHand(Hand.MAIN_HAND).shrink(1);
        }

        player.displayClientMessage(
                new StringTextComponent("Нежить приручена!"),
                true
        );

        // Сбрасываем агрессию
        monster.setTarget(null);

        event.setCancellationResult(ActionResultType.SUCCESS);
        event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onLivingUpdate(LivingEvent.LivingUpdateEvent event) {

        if (!(event.getEntityLiving() instanceof MonsterEntity)) {
            return;
        }

        MonsterEntity monster = (MonsterEntity) event.getEntityLiving();

        CompoundNBT data = monster.getPersistentData();

        // Только приручённые
        if (!data.getBoolean("Peasiful")) {
            return;
        }

        // Не атакует
        monster.setTarget(null);

        String ownerName = data.getString("Owner");

        PlayerEntity nearestPlayer = monster.level.getNearestPlayer(monster, 20);

        if (nearestPlayer == null) {
            return;
        }

        // Только хозяин
        if (!nearestPlayer.getName().getString().equals(ownerName)) {
            return;
        }

        // Следует за игроком
        monster.getNavigation().moveTo(nearestPlayer, 1.0D);
    }
}