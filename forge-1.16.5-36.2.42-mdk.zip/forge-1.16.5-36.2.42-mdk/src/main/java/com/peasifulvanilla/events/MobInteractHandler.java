package com.peasifulvanilla.events;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.monster.CreeperEntity;
import net.minecraft.entity.monster.MonsterEntity;
import net.minecraft.entity.monster.SkeletonEntity;
import net.minecraft.entity.monster.ZombieEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class MobInteractHandler {

    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {

        PlayerEntity player = event.getPlayer();
        LivingEntity target = (LivingEntity) event.getTarget();
        Item item = player.getItemInHand(Hand.MAIN_HAND).getItem();

        // Проверяем монстров
        if (target instanceof ZombieEntity ||
            target instanceof SkeletonEntity ||
            target instanceof CreeperEntity) {

            // Проверяем еду
            if (isTamingFood(item)) {

                // Убираем 1 еду
                if (!player.isCreative()) {
                    player.getItemInHand(Hand.MAIN_HAND).shrink(1);
                }

                // Монстр перестаёт атаковать игрока
                if (target instanceof MonsterEntity) {
                    ((MonsterEntity) target).setTarget(null);
                }

                // Сообщение
                player.sendMessage(
                    new StringTextComponent(target.getName().getString() + " is now peaceful!"),
                    player.getUUID()
                );

                // Атакует других мобов
                target.setLastHurtByMob(player);

                event.setCanceled(true);
            }
        }
    }

    private static boolean isTamingFood(Item item) {

        return item == Items.BEEF ||
               item == Items.COOKED_BEEF ||

               item == Items.PORKCHOP ||
               item == Items.COOKED_PORKCHOP ||

               item == Items.MUTTON ||
               item == Items.COOKED_MUTTON;
    }
}