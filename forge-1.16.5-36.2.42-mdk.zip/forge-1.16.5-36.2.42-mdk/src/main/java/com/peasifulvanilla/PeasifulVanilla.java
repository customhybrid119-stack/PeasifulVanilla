package com.peasifulvanilla;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.common.MinecraftForge;

import com.peasifulvanilla.events.MobTameEvents;

@Mod(PeasifulVanilla.MOD_ID)
public class PeasifulVanilla {

    public static final String MOD_ID =
            "peasifulvanilla";

    public PeasifulVanilla() {

        MinecraftForge.EVENT_BUS.register(
                new MobTameEvents()
        );
    }
}